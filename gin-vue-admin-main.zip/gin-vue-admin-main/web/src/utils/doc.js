export const toDoc = (url) => {
  window.open(url, '_blank')
}
