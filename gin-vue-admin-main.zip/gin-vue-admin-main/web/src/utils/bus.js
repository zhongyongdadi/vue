// using ES6 modules
import mitt from 'mitt'

export const emitter = mitt()
