package service

var Service = new(service)

type service struct{ Info info }
